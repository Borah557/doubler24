<?php
// This file will be populated during installation
return [
    'installed' => false,
];