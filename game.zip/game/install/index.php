<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if already installed
if (file_exists('../config.php') && filesize('../config.php') > 0) {
    $config = include '../config.php';
    if (isset($config['installed']) && $config['installed'] === true) {
        header('Location: ../index.php');
        exit;
    }
}

$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($step === 1) {
        // Check server requirements
        $requirements = [
            'PHP Version' => [version_compare(PHP_VERSION, '7.4.0', '>='), '7.4.0 or higher'],
            'PDO Extension' => [extension_loaded('pdo'), 'Required'],
            'cURL Extension' => [extension_loaded('curl'), 'Required'],
            'JSON Extension' => [extension_loaded('json'), 'Required'],
            'Writable Config' => [is_writable('../') || is_writable('../config.php'), 'Required'],
        ];
        
        $allMet = true;
        foreach ($requirements as $req) {
            if (!$req[0]) {
                $allMet = false;
                break;
            }
        }
        
        if ($allMet) {
            header('Location: index.php?step=2');
            exit;
        } else {
            $error = 'Please fix the requirements before continuing.';
        }
    } elseif ($step === 2) {
        // Database configuration
        $dbHost = $_POST['db_host'] ?? '';
        $dbName = $_POST['db_name'] ?? '';
        $dbUser = $_POST['db_user'] ?? '';
        $dbPass = $_POST['db_pass'] ?? '';
        
        try {
            $dsn = "mysql:host=$dbHost;charset=utf8mb4";
            $pdo = new PDO($dsn, $dbUser, $dbPass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
            
            // Create database if not exists
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbName`");
            $pdo->exec("USE `$dbName`");
            
            // Create tables
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS `users` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `username` VARCHAR(50) NOT NULL UNIQUE,
                    `email` VARCHAR(100) NOT NULL UNIQUE,
                    `password` VARCHAR(255) NOT NULL,
                    `balance_btc` DECIMAL(18,8) DEFAULT 0,
                    `balance_ltc` DECIMAL(18,8) DEFAULT 0,
                    `balance_doge` DECIMAL(18,8) DEFAULT 0,
                    `balance_trx` DECIMAL(18,8) DEFAULT 0,
                    `ref_code` VARCHAR(20) NOT NULL UNIQUE,
                    `referred_by` INT DEFAULT NULL,
                    `is_admin` TINYINT(1) DEFAULT 0,
                    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                )
            ");
            
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS `deposits` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `user_id` INT NOT NULL,
                    `amount` DECIMAL(18,8) NOT NULL,
                    `currency` VARCHAR(10) NOT NULL,
                    `tx_id` VARCHAR(100) DEFAULT NULL,
                    `status` ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
                    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
                )
            ");
            
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS `withdrawals` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `user_id` INT NOT NULL,
                    `amount` DECIMAL(18,8) NOT NULL,
                    `currency` VARCHAR(10) NOT NULL,
                    `address` VARCHAR(100) NOT NULL,
                    `tx_id` VARCHAR(100) DEFAULT NULL,
                    `status` ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
                    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
                )
            ");
            
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS `investments` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `user_id` INT NOT NULL,
                    `amount` DECIMAL(18,8) NOT NULL,
                    `currency` VARCHAR(10) NOT NULL,
                    `return_amount` DECIMAL(18,8) NOT NULL,
                    `status` ENUM('active', 'completed', 'cancelled') DEFAULT 'active',
                    `end_date` DATETIME NOT NULL,
                    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
                )
            ");
            
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS `referrals` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `referrer_id` INT NOT NULL,
                    `referred_id` INT NOT NULL,
                    `commission` DECIMAL(18,8) DEFAULT 0,
                    `currency` VARCHAR(10) NOT NULL,
                    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (`referrer_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
                    FOREIGN KEY (`referred_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
                )
            ");
            
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS `settings` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `key` VARCHAR(50) NOT NULL UNIQUE,
                    `value` TEXT NOT NULL,
                    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                )
            ");
            
            // Insert default settings
            $defaultSettings = [
                ['site_name', 'Crypto Investment Platform'],
                ['site_description', 'A secure platform for cryptocurrency investments'],
                ['coinpayments_public_key', ''],
                ['coinpayments_private_key', ''],
                ['coinpayments_merchant_id', ''],
                ['coinpayments_ipn_secret', ''],
                ['referral_percentage', '50'],
                ['min_deposit_btc', '0.001'],
                ['min_deposit_ltc', '0.01'],
                ['min_deposit_doge', '100'],
                ['min_deposit_trx', '100'],
                ['min_withdraw_btc', '0.002'],
                ['min_withdraw_ltc', '0.02'],
                ['min_withdraw_doge', '200'],
                ['min_withdraw_trx', '200'],
                ['investment_duration_hours', '24'],
                ['investment_return_percentage', '10'],
                ['fake_transaction_interval', '300'] // 5 minutes in seconds
            ];
            
            $stmt = $pdo->prepare("INSERT INTO `settings` (`key`, `value`) VALUES (?, ?)");
            foreach ($defaultSettings as $setting) {
                $stmt->execute($setting);
            }
            
            // Create config file
            $configContent = "<?php\nreturn [\n";
            $configContent .= "    'installed' => true,\n";
            $configContent .= "    'db_host' => '$dbHost',\n";
            $configContent .= "    'db_name' => '$dbName',\n";
            $configContent .= "    'db_user' => '$dbUser',\n";
            $configContent .= "    'db_pass' => '$dbPass',\n";
            $configContent .= "];\n";
            
            file_put_contents('../config.php', $configContent);
            
            header('Location: index.php?step=3');
            exit;
        } catch (PDOException $e) {
            $error = 'Database Error: ' . $e->getMessage();
        }
    } elseif ($step === 3) {
        // Admin account setup
        $username = $_POST['username'] ?? '';
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        
        if (empty($username) || empty($email) || empty($password)) {
            $error = 'All fields are required';
        } elseif ($password !== $confirmPassword) {
            $error = 'Passwords do not match';
        } elseif (strlen($password) < 8) {
            $error = 'Password must be at least 8 characters';
        } else {
            try {
                $config = include '../config.php';
                $dsn = "mysql:host={$config['db_host']};dbname={$config['db_name']};charset=utf8mb4";
                $pdo = new PDO($dsn, $config['db_user'], $config['db_pass'], [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]);
                
                // Generate unique referral code
                $refCode = substr(md5(uniqid(mt_rand(), true)), 0, 8);
                
                // Create admin account
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("
                    INSERT INTO `users` (`username`, `email`, `password`, `ref_code`, `is_admin`) 
                    VALUES (?, ?, ?, ?, 1)
                ");
                $stmt->execute([$username, $email, $hashedPassword, $refCode]);
                
                $success = 'Installation completed successfully!';
                header('Refresh: 3; URL=../index.php');
            } catch (PDOException $e) {
                $error = 'Database Error: ' . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Installation - Crypto Investment Platform</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 40px;
        }
        .install-container {
            max-width: 700px;
            margin: 0 auto;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            padding: 30px;
        }
        .step-indicator {
            display: flex;
            margin-bottom: 30px;
        }
        .step {
            flex: 1;
            text-align: center;
            padding: 10px;
            position: relative;
        }
        .step:not(:last-child):after {
            content: '';
            position: absolute;
            top: 50%;
            right: 0;
            width: 100%;
            height: 2px;
            background: #dee2e6;
            transform: translateY(-50%);
            z-index: 0;
        }
        .step-number {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #dee2e6;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 10px;
            position: relative;
            z-index: 1;
        }
        .step.active .step-number {
            background: #0d6efd;
            color: white;
        }
        .step.completed .step-number {
            background: #198754;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="install-container">
            <h1 class="text-center mb-4">Crypto Investment Platform Installation</h1>
            
            <div class="step-indicator">
                <div class="step <?= $step >= 1 ? 'active' : '' ?> <?= $step > 1 ? 'completed' : '' ?>">
                    <div class="step-number"><?= $step > 1 ? '✓' : '1' ?></div>
                    <div class="step-title">Requirements</div>
                </div>
                <div class="step <?= $step >= 2 ? 'active' : '' ?> <?= $step > 2 ? 'completed' : '' ?>">
                    <div class="step-number"><?= $step > 2 ? '✓' : '2' ?></div>
                    <div class="step-title">Database</div>
                </div>
                <div class="step <?= $step >= 3 ? 'active' : '' ?> <?= $step > 3 ? 'completed' : '' ?>">
                    <div class="step-number"><?= $step > 3 ? '✓' : '3' ?></div>
                    <div class="step-title">Admin Account</div>
                </div>
            </div>
            
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            
            <?php if (!empty($success)): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>
            
            <?php if ($step === 1): ?>
                <h3>System Requirements</h3>
                <form method="post" action="">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Requirement</th>
                                <th>Status</th>
                                <th>Required</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $requirements = [
                                'PHP Version' => [version_compare(PHP_VERSION, '7.4.0', '>='), '7.4.0 or higher'],
                                'PDO Extension' => [extension_loaded('pdo'), 'Required'],
                                'cURL Extension' => [extension_loaded('curl'), 'Required'],
                                'JSON Extension' => [extension_loaded('json'), 'Required'],
                                'Writable Config' => [is_writable('../') || is_writable('../config.php'), 'Required'],
                            ];
                            
                            $allMet = true;
                            foreach ($requirements as $name => $req):
                                $met = $req[0];
                                if (!$met) $allMet = false;
                            ?>
                                <tr>
                                    <td><?= $name ?></td>
                                    <td>
                                        <?php if ($met): ?>
                                            <span class="badge bg-success">OK</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Not Met</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= $req[1] ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary" <?= !$allMet ? 'disabled' : '' ?>>Continue</button>
                    </div>
                </form>
            <?php elseif ($step === 2): ?>
                <h3>Database Configuration</h3>
                <form method="post" action="">
                    <div class="mb-3">
                        <label for="db_host" class="form-label">Database Host</label>
                        <input type="text" class="form-control" id="db_host" name="db_host" value="localhost" required>
                    </div>
                    <div class="mb-3">
                        <label for="db_name" class="form-label">Database Name</label>
                        <input type="text" class="form-control" id="db_name" name="db_name" required>
                    </div>
                    <div class="mb-3">
                        <label for="db_user" class="form-label">Database Username</label>
                        <input type="text" class="form-control" id="db_user" name="db_user" required>
                    </div>
                    <div class="mb-3">
                        <label for="db_pass" class="form-label">Database Password</label>
                        <input type="password" class="form-control" id="db_pass" name="db_pass">
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">Continue</button>
                    </div>
                </form>
            <?php elseif ($step === 3): ?>
                <h3>Admin Account Setup</h3>
                <form method="post" action="">
                    <div class="mb-3">
                        <label for="username" class="form-label">Admin Username</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Admin Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Admin Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                        <div class="form-text">Password must be at least 8 characters long.</div>
                    </div>
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">Complete Installation</button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>