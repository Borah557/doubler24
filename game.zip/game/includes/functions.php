<?php
session_start();

// Authentication functions
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true;
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        header('Location: index.php');
        exit;
    }
}

function login($user) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['is_admin'] = (bool)$user['is_admin'];
}

function logout() {
    session_unset();
    session_destroy();
    header('Location: index.php');
    exit;
}

// Generate a random string
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

// Format cryptocurrency amount
function formatCrypto($amount, $currency) {
    switch (strtoupper($currency)) {
        case 'BTC':
            return number_format($amount, 8) . ' BTC';
        case 'LTC':
            return number_format($amount, 8) . ' LTC';
        case 'DOGE':
            return number_format($amount, 2) . ' DOGE';
        case 'TRX':
            return number_format($amount, 2) . ' TRX';
        default:
            return number_format($amount, 8) . ' ' . strtoupper($currency);
    }
}

// Get user by ID
function getUserById($userId) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    return $stmt->fetch();
}

// Get user balance for specific currency
function getUserBalance($userId, $currency) {
    $user = getUserById($userId);
    $balanceField = 'balance_' . strtolower($currency);
    return $user[$balanceField] ?? 0;
}

// Update user balance
function updateUserBalance($userId, $currency, $amount) {
    $db = getDB();
    $balanceField = 'balance_' . strtolower($currency);
    $stmt = $db->prepare("UPDATE users SET $balanceField = $balanceField + ? WHERE id = ?");
    return $stmt->execute([$amount, $userId]);
}

// CoinPayments API integration
function initCoinPaymentsAPI() {
    require_once __DIR__ . '/../vendor/autoload.php';
    
    $publicKey = getSetting('coinpayments_public_key');
    $privateKey = getSetting('coinpayments_private_key');
    
    return new \CoinPayments\CoinPaymentsAPI($privateKey, $publicKey, 'json');
}

// Create a deposit transaction
function createDepositTransaction($userId, $amount, $currency) {
    try {
        $cp = initCoinPaymentsAPI();
        $merchantId = getSetting('coinpayments_merchant_id');
        
        $req = [
            'amount' => $amount,
            'currency1' => 'USD',
            'currency2' => strtoupper($currency),
            'buyer_email' => getUserById($userId)['email'],
            'item_name' => 'Deposit to account',
            'ipn_url' => 'https://yourdomain.com/ipn_handler.php',
            'success_url' => 'https://yourdomain.com/deposit_success.php',
            'cancel_url' => 'https://yourdomain.com/deposit_cancel.php',
        ];
        
        $result = $cp->CreateTransaction($req);
        
        if ($result['error'] == 'ok') {
            $db = getDB();
            $stmt = $db->prepare("
                INSERT INTO deposits (user_id, amount, currency, tx_id, status) 
                VALUES (?, ?, ?, ?, 'pending')
            ");
            $stmt->execute([$userId, $amount, $currency, $result['result']['txn_id']]);
            
            return $result['result'];
        } else {
            throw new Exception($result['error']);
        }
    } catch (Exception $e) {
        error_log('CoinPayments API Error: ' . $e->getMessage());
        return false;
    }
}

// Process withdrawal
function processWithdrawal($userId, $amount, $currency, $address) {
    try {
        $cp = initCoinPaymentsAPI();
        
        $req = [
            'amount' => $amount,
            'currency' => strtoupper($currency),
            'address' => $address,
            'auto_confirm' => 1,
            'ipn_url' => 'https://yourdomain.com/withdrawal_ipn.php',
        ];
        
        $result = $cp->CreateWithdrawal($req);
        
        if ($result['error'] == 'ok') {
            $db = getDB();
            $stmt = $db->prepare("
                INSERT INTO withdrawals (user_id, amount, currency, address, tx_id, status) 
                VALUES (?, ?, ?, ?, ?, 'pending')
            ");
            $stmt->execute([$userId, $amount, $currency, $address, $result['result']['id']]);
            
            // Deduct from user balance
            updateUserBalance($userId, $currency, -$amount);
            
            return $result['result'];
        } else {
            throw new Exception($result['error']);
        }
    } catch (Exception $e) {
        error_log('CoinPayments API Error: ' . $e->getMessage());
        return false;
    }
}

// Create investment
function createInvestment($userId, $amount, $currency) {
    $db = getDB();
    
    // Get investment settings
    $duration = getSetting('investment_duration_hours');
    $returnPercentage = getSetting('investment_return_percentage');
    
    // Calculate return amount (principal + profit)
    $returnAmount = $amount * (1 + ($returnPercentage / 100));
    
    // Calculate end date
    $endDate = date('Y-m-d H:i:s', strtotime("+$duration hours"));
    
    // Insert investment record
    $stmt = $db->prepare("
        INSERT INTO investments (user_id, amount, currency, return_amount, end_date, status) 
        VALUES (?, ?, ?, ?, ?, 'active')
    ");
    $result = $stmt->execute([$userId, $amount, $currency, $returnAmount, $endDate]);
    
    if ($result) {
        // Deduct from user balance
        updateUserBalance($userId, $currency, -$amount);
        return $db->lastInsertId();
    }
    
    return false;
}

// Process completed investments
function processCompletedInvestments() {
    $db = getDB();
    
    // Get investments that have reached end date
    $stmt = $db->prepare("
        SELECT * FROM investments 
        WHERE status = 'active' AND end_date <= NOW()
    ");
    $stmt->execute();
    $investments = $stmt->fetchAll();
    
    foreach ($investments as $investment) {
        // Update user balance with return amount
        updateUserBalance(
            $investment['user_id'], 
            $investment['currency'], 
            $investment['return_amount']
        );
        
        // Update investment status
        $updateStmt = $db->prepare("
            UPDATE investments SET status = 'completed' WHERE id = ?
        ");
        $updateStmt->execute([$investment['id']]);
    }
    
    return count($investments);
}

// Process referral commission
function processReferralCommission($userId, $amount, $currency) {
    $db = getDB();
    
    // Get user's referrer
    $user = getUserById($userId);
    if (!$user['referred_by']) {
        return false;
    }
    
    // Calculate commission
    $referralPercentage = getSetting('referral_percentage');
    $commission = $amount * ($referralPercentage / 100);
    
    // Add commission to referrer's balance
    updateUserBalance($user['referred_by'], $currency, $commission);
    
    // Record referral transaction
    $stmt = $db->prepare("
        INSERT INTO referrals (referrer_id, referred_id, commission, currency) 
        VALUES (?, ?, ?, ?)
    ");
    return $stmt->execute([$user['referred_by'], $userId, $commission, $currency]);
}

// Generate fake transactions for display
function generateFakeTransactions($type, $count = 10) {
    $db = getDB();
    $currencies = ['btc', 'ltc', 'doge', 'trx'];
    $transactions = [];
    
    // Generate random amounts based on currency
    $amountRanges = [
        'btc' => [0.001, 0.1],
        'ltc' => [0.01, 1.0],
        'doge' => [100, 10000],
        'trx' => [100, 5000]
    ];
    
    // Generate random usernames
    $usernames = [
        'crypto_lover', 'bitcoin_king', 'hodler2025', 'satoshi_fan', 
        'blockchain_pro', 'doge_moon', 'eth_trader', 'crypto_wizard',
        'btc_miner', 'altcoin_guru', 'crypto_whale', 'token_master',
        'digital_gold', 'crypto_investor', 'coin_collector', 'block_explorer'
    ];
    
    // Generate random addresses (shortened for display)
    $addressPrefixes = [
        'btc' => ['1', '3', 'bc1'],
        'ltc' => ['L', 'M', 'ltc1'],
        'doge' => ['D', 'A'],
        'trx' => ['T']
    ];
    
    for ($i = 0; $i < $count; $i++) {
        $currency = $currencies[array_rand($currencies)];
        $amountRange = $amountRanges[$currency];
        $amount = round(mt_rand($amountRange[0] * 100000, $amountRange[1] * 100000) / 100000, 8);
        
        $transaction = [
            'id' => mt_rand(1000, 9999),
            'username' => $usernames[array_rand($usernames)],
            'amount' => $amount,
            'currency' => $currency,
            'timestamp' => date('Y-m-d H:i:s', time() - mt_rand(60, 3600)),
            'status' => 'completed'
        ];
        
        // Add type-specific data
        if ($type === 'deposits') {
            $transaction['tx_id'] = strtoupper(bin2hex(random_bytes(16)));
        } elseif ($type === 'withdrawals') {
            $prefix = $addressPrefixes[$currency][array_rand($addressPrefixes[$currency])];
            $transaction['address'] = $prefix . substr(md5(mt_rand()), 0, 24);
        } elseif ($type === 'investments') {
            $returnPercentage = getSetting('investment_return_percentage');
            $transaction['return_amount'] = round($amount * (1 + ($returnPercentage / 100)), 8);
            $transaction['end_date'] = date('Y-m-d H:i:s', strtotime('+24 hours', strtotime($transaction['timestamp'])));
        }
        
        $transactions[] = $transaction;
    }
    
    // Sort by timestamp (newest first)
    usort($transactions, function($a, $b) {
        return strtotime($b['timestamp']) - strtotime($a['timestamp']);
    });
    
    return $transactions;
}

// Get recent transactions (real + fake)
function getRecentTransactions($type, $limit = 10, $includeFake = true) {
    $db = getDB();
    $realTransactions = [];
    
    // Get real transactions from database
    if ($type === 'deposits') {
        $stmt = $db->prepare("
            SELECT d.id, u.username, d.amount, d.currency, d.created_at as timestamp, d.status, d.tx_id
            FROM deposits d
            JOIN users u ON d.user_id = u.id
            ORDER BY d.created_at DESC
            LIMIT ?
        ");
    } elseif ($type === 'withdrawals') {
        $stmt = $db->prepare("
            SELECT w.id, u.username, w.amount, w.currency, w.created_at as timestamp, w.status, w.address
            FROM withdrawals w
            JOIN users u ON w.user_id = u.id
            ORDER BY w.created_at DESC
            LIMIT ?
        ");
    } elseif ($type === 'investments') {
        $stmt = $db->prepare("
            SELECT i.id, u.username, i.amount, i.currency, i.created_at as timestamp, i.status, i.return_amount, i.end_date
            FROM investments i
            JOIN users u ON i.user_id = u.id
            ORDER BY i.created_at DESC
            LIMIT ?
        ");
    }
    
    $stmt->execute([$limit]);
    $realTransactions = $stmt->fetchAll();
    
    // If we need fake transactions to supplement
    if ($includeFake && count($realTransactions) < $limit) {
        $fakeCount = $limit - count($realTransactions);
        $fakeTransactions = generateFakeTransactions($type, $fakeCount);
        
        // Combine real and fake transactions
        $transactions = array_merge($realTransactions, $fakeTransactions);
        
        // Sort by timestamp (newest first)
        usort($transactions, function($a, $b) {
            return strtotime($b['timestamp']) - strtotime($a['timestamp']);
        });
        
        return $transactions;
    }
    
    return $realTransactions;
}

// Schedule fake transactions to appear every 5 minutes
function scheduleFakeTransactions() {
    $lastRun = getSetting('last_fake_transaction_time');
    $interval = getSetting('fake_transaction_interval'); // in seconds
    
    if (!$lastRun || (time() - strtotime($lastRun) > $interval)) {
        // Generate new fake transactions
        $deposits = generateFakeTransactions('deposits', mt_rand(1, 3));
        $withdrawals = generateFakeTransactions('withdrawals', mt_rand(1, 2));
        
        // Store in session for display
        if (!isset($_SESSION['fake_transactions'])) {
            $_SESSION['fake_transactions'] = [];
        }
        
        $_SESSION['fake_transactions']['deposits'] = array_merge(
            $deposits, 
            $_SESSION['fake_transactions']['deposits'] ?? []
        );
        
        $_SESSION['fake_transactions']['withdrawals'] = array_merge(
            $withdrawals, 
            $_SESSION['fake_transactions']['withdrawals'] ?? []
        );
        
        // Limit stored transactions to prevent session bloat
        if (count($_SESSION['fake_transactions']['deposits']) > 50) {
            $_SESSION['fake_transactions']['deposits'] = array_slice($_SESSION['fake_transactions']['deposits'], 0, 50);
        }
        
        if (count($_SESSION['fake_transactions']['withdrawals']) > 50) {
            $_SESSION['fake_transactions']['withdrawals'] = array_slice($_SESSION['fake_transactions']['withdrawals'], 0, 50);
        }
        
        // Update last run time
        updateSetting('last_fake_transaction_time', date('Y-m-d H:i:s'));
    }
}

// Get supported currencies
function getSupportedCurrencies() {
    return [
        'btc' => [
            'name' => 'Bitcoin',
            'symbol' => 'BTC',
            'icon' => 'fab fa-bitcoin',
            'color' => '#f7931a'
        ],
        'ltc' => [
            'name' => 'Litecoin',
            'symbol' => 'LTC',
            'icon' => 'fab fa-litecoin-sign',
            'color' => '#345d9d'
        ],
        'doge' => [
            'name' => 'Dogecoin',
            'symbol' => 'DOGE',
            'icon' => 'fas fa-dog',
            'color' => '#c3a634'
        ],
        'trx' => [
            'name' => 'Tron',
            'symbol' => 'TRX',
            'icon' => 'fas fa-bolt',
            'color' => '#ff0013'
        ]
    ];
}

// Get minimum deposit amount for a currency
function getMinDepositAmount($currency) {
    return getSetting('min_deposit_' . strtolower($currency));
}

// Get minimum withdrawal amount for a currency
function getMinWithdrawAmount($currency) {
    return getSetting('min_withdraw_' . strtolower($currency));
}

// Format date for display
function formatDate($date) {
    return date('M d, Y H:i', strtotime($date));
}

// Get time remaining until investment completion
function getTimeRemaining($endDate) {
    $endTime = strtotime($endDate);
    $currentTime = time();
    $remainingSeconds = $endTime - $currentTime;
    
    if ($remainingSeconds <= 0) {
        return 'Completed';
    }
    
    $hours = floor($remainingSeconds / 3600);
    $minutes = floor(($remainingSeconds % 3600) / 60);
    
    return $hours . 'h ' . $minutes . 'm';
}

// Get statistics for admin dashboard
function getAdminStats() {
    $db = getDB();
    $stats = [];
    
    // Total users
    $stmt = $db->query("SELECT COUNT(*) as count FROM users");
    $stats['total_users'] = $stmt->fetch()['count'];
    
    // Total deposits
    $stmt = $db->query("SELECT SUM(amount) as total, currency FROM deposits WHERE status = 'completed' GROUP BY currency");
    $stats['total_deposits'] = $stmt->fetchAll();
    
    // Total withdrawals
    $stmt = $db->query("SELECT SUM(amount) as total, currency FROM withdrawals WHERE status = 'completed' GROUP BY currency");
    $stats['total_withdrawals'] = $stmt->fetchAll();
    
    // Active investments
    $stmt = $db->query("SELECT COUNT(*) as count FROM investments WHERE status = 'active'");
    $stats['active_investments'] = $stmt->fetch()['count'];
    
    // Completed investments
    $stmt = $db->query("SELECT COUNT(*) as count FROM investments WHERE status = 'completed'");
    $stats['completed_investments'] = $stmt->fetch()['count'];
    
    // Referral commissions
    $stmt = $db->query("SELECT SUM(commission) as total, currency FROM referrals GROUP BY currency");
    $stats['referral_commissions'] = $stmt->fetchAll();
    
    return $stats;
}

// Clean and validate input
function cleanInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

// Validate email
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Validate cryptocurrency address
function validateCryptoAddress($address, $currency) {
    // Basic validation patterns
    $patterns = [
        'btc' => '/^(bc1|[13])[a-zA-HJ-NP-Z0-9]{25,39}$/',
        'ltc' => '/^[LM3][a-km-zA-HJ-NP-Z1-9]{26,33}$/',
        'doge' => '/^D{1}[5-9A-HJ-NP-U]{1}[1-9A-HJ-NP-Za-km-z]{32}$/',
        'trx' => '/^T[a-zA-Z0-9]{33}$/'
    ];
    
    $currency = strtolower($currency);
    
    if (!isset($patterns[$currency])) {
        return false;
    }
    
    return preg_match($patterns[$currency], $address);
}

// Generate pagination links
function generatePagination($currentPage, $totalPages, $urlPattern) {
    $links = '';
    
    $links .= '<ul class="pagination">';
    
    // Previous button
    if ($currentPage > 1) {
        $links .= '<li class="page-item"><a class="page-link" href="' . sprintf($urlPattern, $currentPage - 1) . '">&laquo;</a></li>';
    } else {
        $links .= '<li class="page-item disabled"><a class="page-link" href="#">&laquo;</a></li>';
    }
    
    // Page numbers
    $startPage = max(1, $currentPage - 2);
    $endPage = min($totalPages, $currentPage + 2);
    
    if ($startPage > 1) {
        $links .= '<li class="page-item"><a class="page-link" href="' . sprintf($urlPattern, 1) . '">1</a></li>';
        if ($startPage > 2) {
            $links .= '<li class="page-item disabled"><a class="page-link" href="#">...</a></li>';
        }
    }
    
    for ($i = $startPage; $i <= $endPage; $i++) {
        if ($i == $currentPage) {
            $links .= '<li class="page-item active"><a class="page-link" href="#">' . $i . '</a></li>';
        } else {
            $links .= '<li class="page-item"><a class="page-link" href="' . sprintf($urlPattern, $i) . '">' . $i . '</a></li>';
        }
    }
    
    if ($endPage < $totalPages) {
        if ($endPage < $totalPages - 1) {
            $links .= '<li class="page-item disabled"><a class="page-link" href="#">...</a></li>';
        }
        $links .= '<li class="page-item"><a class="page-link" href="' . sprintf($urlPattern, $totalPages) . '">' . $totalPages . '</a></li>';
    }
    
    // Next button
    if ($currentPage < $totalPages) {
        $links .= '<li class="page-item"><a class="page-link" href="' . sprintf($urlPattern, $currentPage + 1) . '">&raquo;</a></li>';
    } else {
        $links .= '<li class="page-item disabled"><a class="page-link" href="#">&raquo;</a></li>';
    }
    
    $links .= '</ul>';
    
    return $links;
}